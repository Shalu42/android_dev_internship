package com.noobshubham.gostore.model

data class Southwest(
    var lat: Double = 0.0,
    var lng: Double = 0.0
)
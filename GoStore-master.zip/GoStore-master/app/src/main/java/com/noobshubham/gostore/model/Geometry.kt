package com.noobshubham.gostore.model

data class Geometry(
    var viewport: Viewport? = null,
    var location: Location? = null
)
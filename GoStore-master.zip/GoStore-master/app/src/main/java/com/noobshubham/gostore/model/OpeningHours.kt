package com.noobshubham.gostore.model

data class OpeningHours(
    var open_now: Boolean = false
)
package com.noobshubham.gostore.model

data class Location(
    var lat: Double = 0.0,
    var lng: Double = 0.0
)